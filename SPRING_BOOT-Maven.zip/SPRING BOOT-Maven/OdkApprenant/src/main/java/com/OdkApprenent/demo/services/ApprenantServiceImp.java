/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.OdkApprenent.demo.services;

import com.OdkApprenent.demo.model.Apprenant;
import com.OdkApprenent.demo.repositories.ApprenantRepository;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author awa.keita
 */
@Service
public class ApprenantServiceImp implements ApprenantService {
    @Autowired
    ApprenantRepository apprenantRepository;

    @Override
    public String ajouterApprenant(Apprenant apprenant) {
         this.apprenantRepository.save(apprenant);
         return "Ajout effectuer avec succes:"+apprenant.getPrenom();
    }

    @Override
    @Transactional
    public void modifierApprenant(Integer id, Apprenant apprenant) {
        Apprenant apprenantExistant = apprenantRepository.findById(id).orElseThrow();
        apprenantExistant.setNom(apprenant.getNom());
        apprenantExistant.setPrenom(apprenant.getPrenom());
        apprenantExistant.setAge(apprenant.getAge());
        apprenantExistant.setGenre(apprenant.getGenre());
        apprenantExistant.setMail(apprenant.getMail());
        apprenantExistant.setLogin(apprenant.getLogin());
        apprenantExistant.setPassword(apprenant.getPassword());
        apprenantExistant.setTelephone(apprenant.getTelephone());
        apprenantExistant.setStatus_apprenant(apprenant.getStatus_apprenant());
        apprenantExistant.setDateCreation(apprenant.getDateCreation());
        apprenantExistant.setDateModification(apprenant.getDateModification());
    }
    
    @Override
    public String supprimerApprenant(Integer id) {
        this.apprenantRepository.deleteById(id);
        return "L'apprenant vient d'être supprimer avec succes";
    }

    @Override
    public List<Apprenant> listeApprenant() {
        return apprenantRepository.findAll();
    }
    
    @Override
    public Apprenant afficherApprenant_by_id(Integer id) {
        return apprenantRepository.findById(id).get();
    }

    @Override
    public Apprenant verifieConnection(String login, String password) {
        
        Apprenant verifie = apprenantRepository.findByLoginAndPassword(login, password);
            
        return verifie;
    }

    
    
}
