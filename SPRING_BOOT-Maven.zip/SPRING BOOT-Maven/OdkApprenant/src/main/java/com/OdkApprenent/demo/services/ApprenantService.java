/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.OdkApprenent.demo.services;

import com.OdkApprenent.demo.model.Apprenant;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author awa.keita
 */
@Service
public interface ApprenantService {
    public String ajouterApprenant(Apprenant apprenant);
    public void modifierApprenant(Integer id, Apprenant apprenant);
    public String supprimerApprenant(Integer id);
    public List<Apprenant> listeApprenant();
    public Apprenant afficherApprenant_by_id(Integer id);
    public Apprenant verifieConnection(String login, String password);


    
 
}
