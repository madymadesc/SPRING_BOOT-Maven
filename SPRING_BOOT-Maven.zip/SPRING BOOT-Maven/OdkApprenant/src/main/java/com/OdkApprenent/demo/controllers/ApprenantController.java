/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.OdkApprenent.demo.controllers;

import com.OdkApprenent.demo.model.Apprenant;
import com.OdkApprenent.demo.services.ApprenantService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author awa.keita
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/apprenantOdk")
public class ApprenantController {
    @Autowired
    ApprenantService apprenantService;
    
    @PostMapping(value="/apprenant")
    public String ajout(@RequestBody Apprenant apprenant) {
        return this.apprenantService.ajouterApprenant(apprenant);
    }
    
    @GetMapping(path = "/apprenant/{id}")
    public Apprenant apprenant(@PathVariable Integer id){
        return apprenantService.afficherApprenant_by_id(id);
    }
    
    @GetMapping(path = "/apprenant", produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<Apprenant> liste(){
        return apprenantService.listeApprenant();
    
    }
    
    @PutMapping(path = "/apprenant/{id}")
    public void modifier(@RequestBody Apprenant apprenant, @PathVariable Integer id){
         this.apprenantService.modifierApprenant(id, apprenant);
            
    }
    @DeleteMapping(value = "/apprenant/{id}")
    public String delete(@PathVariable("id") Integer id){
        return this.apprenantService.supprimerApprenant(id);
    }
    @ResponseBody
    @GetMapping(path = "/verifier/{login}/{password}")
    public Apprenant verifieConnection(
            @PathVariable("login") String login,
            @PathVariable("password") String password){
        
        return this.apprenantService.verifieConnection(login, password);
    }
}
