package com.OdkApprenent.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdkApprenantApplicationTests {

	@Test
	void contextLoads() {
	}

}
